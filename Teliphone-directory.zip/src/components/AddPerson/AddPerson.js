import { useState } from "react";
import "./AddPerson.css";
export default function AddPerson({ onButtonClick }) {
	const addPerson = (event) => {
		event.preventDefault();
		if (name !== "" && number !== 0 && String(number).length === 10 && email !== "") {
			onButtonClick("", person);
		}
		else {
			event.preventDefault()
		}
	};
	let [person, setPerson] = useState({
		name: "",
		number: 0,
		email: "",
	});
	let { name, number, email } = person;
	const handleChange = (event) => {
		setPerson({ ...person, [event.target.name]: event.target.value });
	};
	return (
		<section>
			<div className="card pa-30 mr-30">
				<form data-testid="add-person-form" onSubmit={addPerson}>
					<div className="layout-column mb-15">
						<label htmlFor="name" className="mb-3">
							Person Name
						</label>
						<input
							type="text"
							placeholder="Enter Person Name"
							name="name"
							value={name}
							onChange={handleChange}
							data-testid="person-name-input"
						/>
					</div>
					<div className="layout-column mb-15">
						<label htmlFor="number" className="mb-3">
							Phone Number
						</label>
						<input
							type="number"
							placeholder="Enter Phone Number"
							name="number"
							value={number}
							onChange={handleChange}
							data-testid="phone-number-input"
						/>
					</div>
					<div className="layout-column mb-30">
						<label htmlFor="email" className="mb-3">
							Email
						</label>
						<input
							type="email"
							placeholder="Enter Email Address"
							name="email"
							value={email}
							onChange={handleChange}
							data-testid="person-email-input"
						/>
					</div>
					<div className="layout-row justify-content-end">
						<button type="submit" className="mx-0" data-testid="add-person-button">
							Add Person
						</button>
					</div>
				</form>
			</div>
		</section>
	);
}
