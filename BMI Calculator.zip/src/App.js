import React from 'react';
import './App.css';
import 'h8k-components';
import BMICalculator from './components/BMICalculator';

const title = "BMI Calculator";

function App() {
  return (
    <div className="App">
      <h8k-navbar header={title} data-testId="navbar"></h8k-navbar>
      <BMICalculator />
    </div>
  );
}

export default App;
