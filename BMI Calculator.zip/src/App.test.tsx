import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import "@testing-library/jest-dom/extend-expect";
import App from './App';

describe('BMI Calculator', () => {
  beforeEach(() => {
    render(<App />);
  });

  test('renders weight input field', () => {
    const weightInput = screen.getByTestId('weight-input');
    expect(weightInput).toBeInTheDocument();
    fireEvent.change(weightInput, { target: { value: '70' } });
    expect(weightInput).toHaveValue(70);
  });

  test('renders height input field', () => {
    const heightInput = screen.getByTestId('height-input');
    expect(heightInput).toBeInTheDocument();
    fireEvent.change(heightInput, { target: { value: '170' } });
    expect(heightInput).toHaveValue(170);
  });

  test('renders unit selector', () => {
    const unitSelector = screen.getByTestId('unit-selector');
    expect(unitSelector).toBeInTheDocument();
    fireEvent.change(unitSelector, { target: { value: 'metric' } });
    expect(unitSelector).toHaveValue('metric');
  });

  test('calculates BMI for metric units', () => {
    const weightInput = screen.getByTestId('weight-input');
    const heightInput = screen.getByTestId('height-input');
    const calculateButton = screen.getByTestId('calculate-button');

    fireEvent.change(weightInput, { target: { value: '70' } });
    fireEvent.change(heightInput, { target: { value: '170' } });
    fireEvent.click(calculateButton);

    const bmiResult = screen.getByTestId('bmi-result');
    expect(bmiResult).toHaveTextContent('BMI: 24.22');

    const bmiCategory = screen.getByTestId('bmi-category');
    expect(bmiCategory).toHaveTextContent('Category: Normal weight');
  });

  test('calculates BMI for imperial units', () => {
    const weightInput = screen.getByTestId('weight-input');
    const heightInput = screen.getByTestId('height-input');
    const unitSelector = screen.getByTestId('unit-selector');
    const calculateButton = screen.getByTestId('calculate-button');

    fireEvent.change(weightInput, { target: { value: '154' } });
    expect(weightInput).toHaveValue(154);
    fireEvent.change(heightInput, { target: { value: '67' } });
    expect(heightInput).toHaveValue(67);
    fireEvent.change(unitSelector, { target: { value: 'imperial' } });
    fireEvent.click(calculateButton);

    const bmiResult = screen.getByTestId('bmi-result');
    expect(bmiResult).toHaveTextContent('BMI: 24.12');

    const bmiCategory = screen.getByTestId('bmi-category');
    expect(bmiCategory).toHaveTextContent('Category: Normal weight');
  });

  it('calculates BMI for underweight category', () => {
    const weightInput = screen.getByTestId('weight-input');
    const heightInput = screen.getByTestId('height-input');
    const calculateButton = screen.getByTestId('calculate-button');
  
    fireEvent.change(weightInput, { target: { value: '45' } });
    fireEvent.change(heightInput, { target: { value: '170' } });
    fireEvent.click(calculateButton);
  
    const bmiResult = screen.getByTestId('bmi-result');
    expect(bmiResult).toHaveTextContent('BMI: 15.57');
  
    const bmiCategory = screen.getByTestId('bmi-category');
    expect(bmiCategory).toHaveTextContent('Category: Underweight');
  });
  
  it('calculates BMI for overweight category', () => {
    const weightInput = screen.getByTestId('weight-input');
    const heightInput = screen.getByTestId('height-input');
    const calculateButton = screen.getByTestId('calculate-button');
  
    fireEvent.change(weightInput, { target: { value: '85' } });
    fireEvent.change(heightInput, { target: { value: '170' } });
    fireEvent.click(calculateButton);
  
    const bmiResult = screen.getByTestId('bmi-result');
    expect(bmiResult).toHaveTextContent('BMI: 29.41');
  
    const bmiCategory = screen.getByTestId('bmi-category');
    expect(bmiCategory).toHaveTextContent('Category: Overweight');
  });
  
  test('calculates BMI and displays "Obesity" category', () => {
    const weightInput = screen.getByTestId('weight-input');
    const heightInput = screen.getByTestId('height-input');
    const unitSelector = screen.getByTestId('unit-selector');
    const calculateButton = screen.getByTestId('calculate-button');
  
    fireEvent.change(weightInput, { target: { value: '100' } });
    fireEvent.change(heightInput, { target: { value: '170' } });
    fireEvent.click(calculateButton);
  
    const bmiResult = screen.getByTestId('bmi-result');
    expect(bmiResult).toHaveTextContent('BMI: 34.60');
    
    const bmiCategory = screen.getByTestId('bmi-category');
    expect(bmiCategory).toHaveTextContent('Category: Obesity');
  });

  test('does not calculate BMI for empty input', () => {
    const weightInput = screen.getByTestId('weight-input');
    const heightInput = screen.getByTestId('height-input');
    const calculateButton = screen.getByTestId('calculate-button');

    fireEvent.change(weightInput, { target: { value: '' } });
    expect(weightInput).toHaveValue(null);
    fireEvent.change(heightInput, { target: { value: '' } });
    expect(heightInput).toHaveValue(null);
    fireEvent.click(calculateButton);

    const bmiResult = screen.getByTestId('bmi-result');
    expect(bmiResult).toHaveTextContent('BMI: -');

    const bmiCategory = screen.getByTestId('bmi-category');
    expect(bmiCategory).toHaveTextContent('Category: -');

    const unitSelector = screen.getByTestId('unit-selector');
    expect(unitSelector).toHaveValue('metric');
  });

  it('uses metric as the default unit', () => {
    const unitSelector = screen.getByTestId('unit-selector');
    expect(unitSelector).toHaveValue('metric');
  });
  
  it('handles valid weight input and invalid height input', () => {
    const weightInput = screen.getByTestId('weight-input');
    const heightInput = screen.getByTestId('height-input');
    const calculateButton = screen.getByTestId('calculate-button');
  
    fireEvent.change(weightInput, { target: { value: '70' } });
    expect(weightInput).toHaveValue(70);
    fireEvent.change(heightInput, { target: { value: '-170' } });
    fireEvent.click(calculateButton);
  
    const bmiResult = screen.getByTestId('bmi-result');
    const bmiCategory = screen.getByTestId('bmi-category');
  
    expect(bmiResult).toHaveTextContent('BMI: -');
    expect(bmiCategory).toHaveTextContent('Category: -');
  });
  
  it('handles invalid weight input and valid height input', () => {
    const weightInput = screen.getByTestId('weight-input');
    const heightInput = screen.getByTestId('height-input');
    const calculateButton = screen.getByTestId('calculate-button');
  
    fireEvent.change(weightInput, { target: { value: '-70' } });
    fireEvent.change(heightInput, { target: { value: '170' } });
    expect(heightInput).toHaveValue(170);
    fireEvent.click(calculateButton);
  
    const bmiResult = screen.getByTestId('bmi-result');
    const bmiCategory = screen.getByTestId('bmi-category');
  
    expect(bmiResult).toHaveTextContent('BMI: -');
    expect(bmiCategory).toHaveTextContent('Category: -');
  });
  
});
