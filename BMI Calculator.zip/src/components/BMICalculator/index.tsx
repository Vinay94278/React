import React, { useState } from 'react';
import './index.css';

type Unit = 'metric' | 'imperial';

const weight = 0;
const height = 0;

const BMICalculator: React.FC = () => {
  return (
    <div className="layout-column align-items-center justify-content-start bmi-calculator" data-testid="bmi-calculator">
      <div className="bmi-calculator-scale card w-200 pt-30 pb-8 mt-20 mb-15">
        <section className="layout-row align-items-center justify-content-center mr-20 ml-20">
          <label htmlFor="weight">Weight:</label>
          <input type="number" id="weight" data-testid="weight-input" value={weight || ''} onChange={() => {}}/>(lbs)
        </section>
        <section className="layout-row align-items-center justify-content-center mt-20 mr-20 ml-20">
          <label htmlFor="height">Height:</label>
          <input type="number" id="height" data-testid="height-input" value={height || ''} onChange={() => {}}/>(in)
        </section>
        <section className="layout-row align-items-center justify-content-center mt-20 mr-20 ml-20">
          <label htmlFor="unit">Unit:</label>
          <select id="unit" data-testid="unit-selector" value="imperial" onChange={() => {}}>
            <option value="metric">Metric</option>
            <option value="imperial">Imperial</option>
          </select>
        </section>
        <section className="layout-row align-items-center justify-content-center mt-20 mr-20 ml-20">
          <button data-testid="calculate-button">Calculate</button>
        </section>
      </div>
      <div className="bmi-calculator-result card w-200 mt-10 pt-10 pb-10">
        <section className="layout-row align-items-center justify-content-center pl-50 pr-50">
          <p data-testid="bmi-result">BMI: -</p>
        </section>
        <section className="layout-row align-items-center justify-content-center pl-50 pr-50">
          <p data-testid="bmi-category">Category: -</p>
        </section>
      </div>
    </div>
  );
};

export default BMICalculator;
