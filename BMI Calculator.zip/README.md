## React Typescript: BMI Calculator

![](https://hrcdn.net/s3_pub/istreet-assets/tmiJtPWqL8cD9qz-vai2-Q/bmi-calculator.gif)

Design a Body Mass Index (BMI) calculator app that allow users to input their _weight_ and _height_, then calculate and display their BMI using typescript and react. The app should work for both _Metric_ and _Imperial_ units, defined in type _Unit_. Certain core React functionalities are already implemented.

The application has one component: _BMICalculator/index.tsx_ where all the functionalities will be implemented.

The component must have the following functionalities:

- Allow users to input their _weight_ and _height_.
- Handle edge cases for _weight_ and _height_ input:
  - If the input is negative or 0, set it to ''
- Allow users to switch between _Metric_ and _Imperial_ units.
  - Default value for unit should be _Metric_
  - Default value for _weight_ should be ""
  - Default value for _height_ should be ""
  - Default value for BMI should be "-"
  - Default value for Category should be "-"
- Calculate and display the BMI based on the provided _weight_ and _height_ using the following formulas:

| **Unit**     | **Formula**                                     |
|--------------|-------------------------------------------------|
| _Metric_     | BMI = weight (kg) / ((height (cm) / 100) ^ 2)   |
| _Imperial_   | BMI = (703 * weight (lbs)) / (height (in) ^ 2)  |

- Display the BMI category according to the calculated BMI value:

| **BMI Category**   | **BMI Range**        |
|--------------------|----------------------|
| Underweight        | BMI < 18.5           |
| Normal weight      | 18.5 ≤ BMI ≤ 24.9    | 
| Overweight         | 25 ≤ BMI ≤ 29.9      | 
| Obesity            | BMI ≥ 30             | 

- The final value for BMI should be rounded to two decimal places.
- If unit is _Metric_:
  - _weight_ should be in "kg"
  - _height_ should be in "cm"
  - BMI should be calculated using this formula: `BMI = weight (kg) / ((height (cm) / 100) ^ 2)`
- If unit is _Imperial_:
  - _weight_ should be in "lbs"
  - _height_ should be in "in"
  - BMI_ should be calculated using this formula: `BMI = (703 * weight (lbs)) / (height (in) ^ 2)`

The following _data-testid_ attributes are required in the components for the tests to pass:

| **Attribute**          | **Component**               |
|------------------------|-----------------------------|
| _bmi-calculator_       | BMICalculator component     |
| _weight-input_         | Weight input field          |
| _height-input_         | Height input field          |
| _unit-selector_        | Unit selection dropdown     |
| _calculate-button_     | Calculate button            |
| _bmi-result_           | BMI result display          |
| _bmi-category_         | BMI category display        |

Note:

- Components have _data-testid_ attributes for test cases and certain classes and ids for rendering purposes. They should not be changed.
- The files that should be modified by the candidate are _src/components/BMICalculator/index.tsx_.

## Environment 

- React Version: 18
- Node Version: 22(LTS)
- Default Port: 8000


**Read Only Files**
- `src/App.test.tsx`


**Commands**
- run: 
```bash
npm start
```
- install: 
```bash
npm install
```
- test: 
```bash
npm test
```

