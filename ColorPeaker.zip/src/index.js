import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import App from './App';
import registerServiceWorker from './registerServiceWorker';
import { applyPolyfills, defineCustomElements } from 'h8k-components/loader';

const container = document.getElementById('root');
const root = createRoot(container);
root.render(<App colorPickerOptions={['#5d77f5', '#0fd085', '#ffba5b', '#f95e62', 'lightpink']}
  initialSelectedColor={'black'} />);
registerServiceWorker();

applyPolyfills()
  .then(() => {
    return defineCustomElements(window);
  })