# React FORM Validation
Given a partially completed React application with the HTML template and few built-in functionalities, your task is to validate the fields in the form based on few constraints that are specified.


Certain core React functionalities have already been implemented. Complete the React application as shown below in order to pass all the tests.

![](https://hrcdn.net/s3_pub/istreet-assets/EJhQmThbBY1RbjIsJc2ZDw/Screen%20Recording%202020-07-19%20at%2010.39.46%20AM.gif)

The application has 1 Component:
- A Form Component which holds 4 input fields 'Name', 'Email', 'Phone' and 'Blog Url'


The app should implement the following functionalities:
 - The user should be able to fill in the contents of all 4 fields.
 - When verify button is clicked, the values in all the fields should be validated as per the constraints.
 - The Error message fields should be rendered below the corresponding field only if the validation for that field fails.
 - If the values in all the fields are valid, on clicking the `verify` button should show the `Verification Successful` message below it.


The validation rules for each fields are given below:
- The `Name` field should accept only alphabets and empty spaces. The name should contain at least 3 alphabets. The total length of the name should not exceed 25 characters
- The `Email` field should have the following rules:
	-	Eg: john.doe3@hackerrank.com
	- It should start with an alphabet and can contain combinations of alphabet, digits and dot until it reaches the symbol @
	- It can have 3 to 20 characters before the symbol @
	- After the symbol @ , it should contain 3 to 10 alphabetic characters before encountering dot symbol (.)
	- After the (.) dot symbol, it should contain 3 to 10 alphabetic characters.	
- The `Phone` field should accept only numbers and its length should be exactly 10.
- The `Blog URL` field should have the following rules:
	- The Url should start with 'https://'
	- It should be followed by 3 to 10 alphabetic characters before the first dot (.)
	- After first dot, it should have 3 to 20 alphabetic characters until the second dot (.)
	- And after the second dot it should have 2 to 5 alphabetic characters.

The following data-testid attributes are required in the component for the tests to pass:
* The `Name` <input> tag should have the data-testid `name` and its corresponding element to show error message should have `nameErrorTxt` as its data-testid.
* The `Email` <input> tag should have the data-testid `email` and its corresponding element to show error message should have `emailErrorTxt` as its data-testid.
* The `Phone` <input> tag should have the data-testid `phone` and its corresponding element to show error message should have `phoneErrorTxt` as its data-testid.
* The `Blog URL` <input> tag should have the data-testid `url` and its corresponding element to show error message should have `urlErrorTxt` as its data-testid.
* The Verify button should have the data-testid `verify`.
* The element that shows the success message should have the data-testid `successMsg`.

Please note that the component has the above data-testid attributes for test cases. It is advised not to change them.

## Environment 

- React Version: 16.13.1
- Node Version: ^12.18.3
- Default Port: 8000

**Read Only Files**
- `src/App.test.js`


**Commands**
- run: 
```bash
bash bin/env_setup && . $HOME/.nvm/nvm.sh && npm start
```
- install: 
```bash
bash bin/env_setup && . $HOME/.nvm/nvm.sh && npm install
```
- test: 
```bash
bash bin/env_setup && . $HOME/.nvm/nvm.sh && npm test
```

