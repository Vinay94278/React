import React from 'react';
import { validateEmail, validateUrl } from '../utils';

function Form() {
	return (
		<div className="card w-40 mx-auto py-50 px-50 my-10">
			<div>
				<div className="layout-column">
					<label htmlFor="name">Name</label>
					<input id="name" data-testid="name" placeholder="John Doe" className="large mt-8 px-10" />
					<p data-testid="nameErrorTxt" className="form-hint error-text mx-10" id="hint-input">Error: Invalid Entry</p>
				</div>
			</div>
			<div>
				<div className="mt-15 layout-column">
					<label htmlFor="email">Email</label>
					<input id="email" data-testid="email" placeholder="johndoe@hackerrank.com" className="large mt-8 px-10" />
					<p data-testid="emailErrorTxt" className="form-hint error-text mx-10" id="hint-input">Error: Invalid Entry</p>
				</div>
			</div>
			<div>
				<div className="mt-15 layout-column">
					<label htmlFor="phone">Phone</label>
					<input id="phone" data-testid="phone" placeholder="1234567890" className="large mt-8 px-10" />
					<p data-testid="phoneErrorTxt" className="form-hint error-text mx-10" id="hint-input">Error: Invalid Entry</p>
				</div>
			</div>
			<div>
				<div className="mt-15 layout-column">
					<label htmlFor="blogUrl">Blog URL</label>
					<input id="blogUrl" data-testid="url" placeholder="https://www.johndoe.dev" className="large mt-8 px-10" />
					<p data-testid="urlErrorTxt" className="form-hint error-text mx-10" id="hint-input">Error: Invalid Entry</p>
				</div>
			</div>
			<button data-testid="verify" className="button mt-40" type="button">VERIFY</button>
			<div data-testid="successMsg" className="success-text success-text text-center py-40">Verification Successful</div>
		</div>
	);
}
export default Form;
