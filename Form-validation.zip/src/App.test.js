import React from 'react';
import App from './App';
import '@testing-library/jest-dom/extend-expect';
import { render, fireEvent, cleanup } from '@testing-library/react';
import '@testing-library/jest-dom/extend-expect';

const TEST_IDS = {
    NAME: 'name',
    NAME_ERR: 'nameErrorTxt',
    PHONE: 'phone',
    PHONE_ERR: 'phoneErrorTxt',
    EMAIL: 'email',
    EMAIL_ERR: 'emailErrorTxt',
    URL: 'url',
    URL_ERR: 'urlErrorTxt',
    VERIFY: 'verify',
    SUCCESSMSG: 'successMsg'
};

const INVALID_NAMES_LIST = ['d', 'Hastings45 g', '4', '9000', '#$%', '!`~', '         ', 'Hubert Blaine Wolfeschlegelsteinhausenbergerdorff Sr'];
const VALID_NAMES_LIST = ['Tom', 'Tom Hanks', 'abcdefghijklmn pqrstuvwxy'];
const INVALID_PH_NO_LIST = ['98', '999999999', '#@#$@#%%%%', '9898989898989898', 'dewdewdwedwed', 'ee'];
const VALID_PH_NO_LIST = ['9999999999', '1234567890', '3333333333'];
const INVALID_EMAIL_LIST = ['a@gmail.com', '0@0.0', '#$#$@#$', 'a34ferf@ede.ededjbrjhbrhj', 'abcdefghijklmnopqrstuvwx@dee.dde', 'dewdwedwed@abcdefghijklmnopqrstuvwx.dde']
const VALID_EMAIL_LIST = ['johndoe@gmail.com', 'abs123@hotmail.com', 'programmers@hackerrank.com'];
const INVALID_URLS_LIST = ['2213213.2232.ccc', '#@#$#@$@2323.21323', 'https://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.abc.com'];
const VALID_URLS_LIST = ['https://www.hackerrank.com', 'https://www.example.com', 'https://www.hello.in'];

describe('form-validation', () => {
    let app;
    let container;
    let getByTestId;
    let queryByTestId;
    let $name;
    let $phone;
    let $email;
    let $url;
    let $verify;

    beforeEach(() => {
        app = render(<App />);
        container = app.container;
        getByTestId = app.getByTestId;
        queryByTestId = app.queryByTestId;
    });

    afterEach(() => {
        cleanup();
    });

    it('should validate Name correctly', () => {
        $name = queryByTestId(TEST_IDS.NAME);
        expect($name).toBeInstanceOf(HTMLElement);
        expect($name.value).toEqual('');
        $verify = queryByTestId(TEST_IDS.VERIFY);
        fireEvent.click($verify);
        let $nameErr = queryByTestId('nameErrorTxt');
        expect($nameErr.textContent.trim()).toEqual(`Error: Invalid Entry`);
        INVALID_NAMES_LIST.forEach((val) => {
            fireEvent.change($name, { target: { value: val } });
            fireEvent.click($verify);
            let $nameErr = queryByTestId('nameErrorTxt');
            expect($nameErr).toBeTruthy();
            expect($nameErr.textContent.trim()).toEqual(`Error: Invalid Entry`);
        });

        VALID_NAMES_LIST.forEach((val) => {
            fireEvent.change($name, { target: { value: val } });
            expect($name.value).toEqual(val);
            fireEvent.click($verify);
            expect(queryByTestId('nameErrorTxt')).toBeNull();
        });
    });

    it('should validate Phone Number correctly', () => {
        $phone = queryByTestId(TEST_IDS.PHONE);
        expect($phone).toBeInstanceOf(HTMLElement);
        expect($phone.value).toEqual('');
        $verify = queryByTestId(TEST_IDS.VERIFY);
        fireEvent.click($verify);
        let $phoneErr = queryByTestId(TEST_IDS.PHONE_ERR);
        expect($phoneErr.textContent.trim()).toEqual(`Error: Invalid Entry`);
        INVALID_PH_NO_LIST.forEach((val) => {
            fireEvent.change($phone, { target: { value: val } });
            fireEvent.click($verify);
            let $phoneErr = queryByTestId(TEST_IDS.PHONE_ERR);
            expect($phoneErr).toBeTruthy();
            expect($phoneErr.textContent.trim()).toEqual(`Error: Invalid Entry`);
        });

        VALID_PH_NO_LIST.forEach((val) => {
            fireEvent.change($phone, { target: { value: val } });
            expect($phone.value).toEqual(val);
            fireEvent.click($verify);
            expect(queryByTestId(TEST_IDS.PHONE_ERR)).toBeNull();
        });
    });

    it('should validate Emails correctly', () => {
        $email = queryByTestId(TEST_IDS.EMAIL);
        expect($email).toBeInstanceOf(HTMLElement);
        expect($email.value).toEqual('');
        $verify = queryByTestId(TEST_IDS.VERIFY);
        fireEvent.click($verify);
        let $emailErr = queryByTestId(TEST_IDS.EMAIL_ERR);
        expect($emailErr.textContent.trim()).toEqual(`Error: Invalid Entry`);
        INVALID_EMAIL_LIST.forEach((val) => {
            fireEvent.change($email, { target: { value: val } });
            fireEvent.click($verify);
            let $emailErr = queryByTestId(TEST_IDS.EMAIL_ERR);
            expect($emailErr).toBeTruthy();
            expect($emailErr.textContent.trim()).toEqual(`Error: Invalid Entry`);
        });

        VALID_EMAIL_LIST.forEach((val) => {
            fireEvent.change($email, { target: { value: val } });
            expect($email.value).toEqual(val);
            fireEvent.click($verify);
            expect(queryByTestId(TEST_IDS.EMAIL_ERR)).toBeNull();
        });
    });

    it('should validate URLs correctly', () => {
        $url = queryByTestId(TEST_IDS.URL);
        expect($url).toBeInstanceOf(HTMLElement);
        expect($url.value).toEqual('');
        $verify = queryByTestId(TEST_IDS.VERIFY);
        fireEvent.click($verify);
        let $urlErr = queryByTestId(TEST_IDS.URL_ERR);
        expect($urlErr.textContent.trim()).toEqual(`Error: Invalid Entry`);
        INVALID_URLS_LIST.forEach((val) => {
            fireEvent.change($url, { target: { value: val } });
            fireEvent.click($verify);
            let $urlErr = queryByTestId(TEST_IDS.URL_ERR);
            expect($urlErr).toBeTruthy();
            expect($urlErr.textContent.trim()).toEqual(`Error: Invalid Entry`);
        });

        VALID_URLS_LIST.forEach((val) => {
            fireEvent.change($url, { target: { value: val } });
            expect($url.value).toEqual(val);
            fireEvent.click($verify);
            expect(queryByTestId(TEST_IDS.URL_ERR)).toBeNull();
        });
    });

    it('should validate the entire form on right input after series of operations', () => {
        $name = queryByTestId(TEST_IDS.NAME);
        $phone = queryByTestId(TEST_IDS.PHONE);
        $email = queryByTestId(TEST_IDS.EMAIL);
        $url = queryByTestId(TEST_IDS.URL);

        fireEvent.change($name, { target: { value: VALID_NAMES_LIST[0] } });
        fireEvent.change($phone, { target: { value: VALID_PH_NO_LIST[0] } });
        fireEvent.change($email, { target: { value: VALID_EMAIL_LIST[0] } });
        fireEvent.change($url, { target: { value: VALID_URLS_LIST[0] } });
        $verify = queryByTestId(TEST_IDS.VERIFY);
        fireEvent.click($verify);
        let $successMsg = queryByTestId(TEST_IDS.SUCCESSMSG);
        expect($successMsg).toBeTruthy();
        expect($successMsg.textContent.trim()).toEqual(`Verification Successful`);
        fireEvent.change($url, { target: { value: INVALID_URLS_LIST[0] } });
        fireEvent.click($verify);
        $successMsg = queryByTestId(TEST_IDS.SUCCESSMSG);
        expect(queryByTestId(TEST_IDS.SUCCESSMSG)).toBeNull();
        fireEvent.change($url, { target: { value: VALID_URLS_LIST[0] } });
        fireEvent.click($verify);
        $successMsg = queryByTestId(TEST_IDS.SUCCESSMSG);
        expect($successMsg).toBeTruthy();
        expect($successMsg.textContent.trim()).toEqual(`Verification Successful`);
    });
});
