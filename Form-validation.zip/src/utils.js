function validateEmail(email) {
	const regex = /^[a-zA-Z]{1}[a-zA-Z0-9]{2,19}@[a-zA-Z]{3,10}\.[a-zA-Z]{3,5}$/;
	return regex.test(email);
}

function validateUrl(url) {
	const regex = /https:\/\/[a-zA-Z]{3,10}.[a-zA-Z]{3,20}.[a-zA-Z]{2,5}$/;
	return regex.test(url);
}

export {
	validateEmail,
	validateUrl
}