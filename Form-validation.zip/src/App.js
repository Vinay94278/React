import React, {Component} from 'react';
import './App.css';
import 'h8k-components';
import Form from './Components/Form';
import { applyPolyfills, defineCustomElements } from 'h8k-components/loader';

const title = "Form Validation";

class App extends Component {

    render() {
        return (
            <div className="App">
                <h8k-navbar header={title}></h8k-navbar>
                <Form/>
            </div>
        );
    }
}

applyPolyfills().then(() => {
    defineCustomElements(window);
});

export default App;
