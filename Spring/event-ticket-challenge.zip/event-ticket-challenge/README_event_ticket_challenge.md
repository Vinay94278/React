# Event & Ticket Spring Boot Challenge

## Problem Overview
You are given a partially implemented Spring Boot project. Your task is to implement the missing logic in Controller, Service, DTO conversion, and Date handling so that all provided JUnit test cases pass successfully.

## Entities

### Event
- eventId (Long, PK, Auto Generated)
- eventName (String)
- price (double)
- eventDate (LocalDateTime)
- tickets (List<Ticket>)

### Ticket
- ticketId (Long, PK, Auto Generated)
- ticketPrice (double)
- event (Many-To-One to Event)

## DTO Requirements

### EventRequestDTO
- name : String
- price : double
- eventDate : String

### EventResponseDTO
- id : Long
- name : String
- price : double
- eventDate : String

### TicketRequestDTO
- price : double
- eventId : Long

### TicketResponseDTO
- id : Long
- price : double
- eventId : Long

### ViewDTO
- message : String

## API Requirements

### Create Event
POST /events

### Get Events Between Date Range
GET /events/between?start={...}&end={...}

### Delete Event
DELETE /events/{id}

## Constraints
- Entities use LocalDateTime
- DTOs always use String for dates
- Must convert between String and LocalDateTime manually
- Return [] instead of null for empty lists
- Validate negative prices
- Return proper HTTP status codes

## Test Coverage Summary
- Create Event returns 201
- Date format in DTO must be String
- Date range filter works
- Negative price -> 400
- Invalid date -> 400
- Delete missing event -> 404
- Persist events to DB
- Ensure JSON fields exist
- Auto ID generation
- Empty range returns []

## Goal
Run `mvn test` and make all tests pass without modifying tests.
