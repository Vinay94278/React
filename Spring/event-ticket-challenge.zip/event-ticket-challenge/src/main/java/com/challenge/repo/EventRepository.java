package com.challenge.repo;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//import com.challenge.entity.Event;
//import org.springframework.data.jpa.repository.JpaRepository;
//import java.time.LocalDateTime;
//import java.util.*;
//
//public interface EventRepository extends JpaRepository<Event, Long> {
//	List<Event> findByEventDateBetween(LocalDateTime s, LocalDateTime e);
//}


import com.challenge.entity.Event;

@Repository
public interface EventRepository extends JpaRepository<Event, Long> {
	List<Event> findByEventDateBetween(LocalDate s, LocalDate e);
}