package com.challenge.service;

import java.time.LocalDate;
import java.util.List;

import com.challenge.dto.EventRequestDTO;
import com.challenge.dto.EventResponseDTO;
import com.challenge.dto.PurchaseRequestDto;
import com.challenge.dto.PurchaseResponseDto;
import com.challenge.exceptions.EventNotFoundException;
import com.challenge.exceptions.TicketsOutOfBoundException;

public interface EventService {
	
	public EventResponseDTO createEvent(EventRequestDTO requestDTO);
	
	public List<EventResponseDTO> getAllEvents();
	
	public EventResponseDTO getEventById(Long id) throws EventNotFoundException;
	
	public List<EventResponseDTO> filterEvents(LocalDate startDate , LocalDate endDate);
	
	public PurchaseResponseDto purchaseEvent(PurchaseRequestDto requestDto) throws EventNotFoundException, TicketsOutOfBoundException;
	
}