package com.challenge.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

public class EventRequestDTO {
	
	
	private String eventName;
	private LocalDate date;
	//private String date;
	private BigDecimal price;
	private int availableTickets;
	
	
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	public int getAvailableTickets() {
		return availableTickets;
	}
	public void setAvailableTickets(int availableTickets) {
		this.availableTickets = availableTickets;
	}
	
}