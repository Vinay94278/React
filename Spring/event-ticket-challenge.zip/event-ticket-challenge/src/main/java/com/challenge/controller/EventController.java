package com.challenge.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.challenge.dto.EventRequestDTO;
import com.challenge.dto.EventResponseDTO;
import com.challenge.dto.PurchaseRequestDto;
import com.challenge.dto.PurchaseResponseDto;
import com.challenge.exceptions.EventNotFoundException;
import com.challenge.exceptions.TicketsOutOfBoundException;
import com.challenge.service.EventService;

@RestController
@RequestMapping("/api/events")
public class EventController {
	
	private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	//private final DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

	@Autowired
	private EventService eventService;

	@PostMapping
	public ResponseEntity<EventResponseDTO> createEvent(@RequestBody EventRequestDTO requestDTO) {
		//try{
			LocalDate.parse(requestDTO.getDate().toString(), formatter);
		
		return ResponseEntity.status(201).body(eventService.createEvent(requestDTO));
	}

	@GetMapping("/{id}")
	public ResponseEntity<EventResponseDTO> getEventById(@PathVariable Long id) throws EventNotFoundException {
		return ResponseEntity.status(200).body(eventService.getEventById(id));
	}

	@GetMapping
	public ResponseEntity<List<EventResponseDTO>> getAllEvents() {
		return ResponseEntity.status(200).body(eventService.getAllEvents());
	}

	@GetMapping("/filtered/{startDate}/{endDate}")
	public ResponseEntity<List<EventResponseDTO>> getAllEventsByDateBetween(@PathVariable LocalDate startDate , @PathVariable LocalDate endDate)
	{
		return ResponseEntity.status(200).body(eventService.filterEvents(startDate, endDate));
	}
	
	@PostMapping("/purchase")
	public ResponseEntity<PurchaseResponseDto> purchaseEvent(@RequestBody PurchaseRequestDto requestDto) throws EventNotFoundException, TicketsOutOfBoundException
	{
		return ResponseEntity.status(200).body(eventService.purchaseEvent(requestDto));
	}    
	
}