package com.challenge.dto;

public class ViewDTO {
	private String message;

	public ViewDTO() {
	}

	public ViewDTO(String message) {
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String m) {
		this.message = m;
	}
}