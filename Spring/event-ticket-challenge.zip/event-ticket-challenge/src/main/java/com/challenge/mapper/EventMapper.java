package com.challenge.mapper;

import org.springframework.stereotype.Component;

import com.challenge.dto.EventRequestDTO;
import com.challenge.dto.EventResponseDTO;
import com.challenge.entity.Event;

@Component
public class EventMapper {
	
	public Event toEventEntity(EventRequestDTO dto)
	{
		Event event = new Event();
		
		event.setEventName(dto.getEventName());
		event.setAvailableTickets(dto.getAvailableTickets());
		event.setEventDate(dto.getDate());
		event.setPrice(dto.getPrice());
		
		return event;
		
	}
	
	public EventResponseDTO toDto(Event event)
	{
		EventResponseDTO responseDTO = new EventResponseDTO();
		responseDTO.setEventName(event.getEventName());
		responseDTO.setId(event.getEventId());
		responseDTO.setAvailableTickets(event.getAvailableTickets());
		responseDTO.setPrice(event.getPrice());
		responseDTO.setDate(event.getEventDate());
		
		return responseDTO;
	}

}
