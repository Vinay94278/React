package com.challenge.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.challenge.dto.EventRequestDTO;
import com.challenge.dto.EventResponseDTO;
import com.challenge.dto.PurchaseRequestDto;
import com.challenge.dto.PurchaseResponseDto;
import com.challenge.entity.Event;
import com.challenge.exceptions.EventNotFoundException;
import com.challenge.exceptions.TicketsOutOfBoundException;
import com.challenge.mapper.EventMapper;
import com.challenge.repo.EventRepository;

@Service
public class EventServiceImpl implements EventService {

	@Autowired
	private EventRepository repository;

	@Autowired
	private EventMapper eventMapper;

	@Override
	public EventResponseDTO createEvent(EventRequestDTO requestDTO) {

		Event savedEvent = repository.save(eventMapper.toEventEntity(requestDTO));

		return eventMapper.toDto(savedEvent);
	}

	@Override
	public List<EventResponseDTO> getAllEvents() {

		List<EventResponseDTO> listDto = repository.findAll().stream().map(event -> eventMapper.toDto(event)).toList();

		return listDto;
	}

	@Override
	public EventResponseDTO getEventById(Long id) throws EventNotFoundException {

		Event event = repository.findById(id)
				.orElseThrow(() -> new EventNotFoundException("Event Not Found With Id : " + id));

		return eventMapper.toDto(event);
	}

	@Override
	public List<EventResponseDTO> filterEvents(LocalDate startDate, LocalDate endDate) {

//		List<Event> eventList=repository.findByEventDateBetween(startDate, endDate);
		List<Event> eventList = repository.findAll().stream()
				.filter((e) -> e.getEventDate().isAfter(startDate) && e.getEventDate().isBefore(endDate)).toList();

		return eventList.stream().map(e -> eventMapper.toDto(e)).toList();
	}

	@Override
	public PurchaseResponseDto purchaseEvent(PurchaseRequestDto requestDto)
			throws EventNotFoundException, TicketsOutOfBoundException {

		Event event = repository.findById(requestDto.getId())
				.orElseThrow(() -> new EventNotFoundException("Event Not Found With Id : " + requestDto.getId()));

		if (event.getAvailableTickets() < requestDto.getQuantity()) {
			throw new TicketsOutOfBoundException("Tickets are not available");
		}

		event.setAvailableTickets(event.getAvailableTickets() - requestDto.getQuantity());

		Event updatedEvent = repository.save(event);

		PurchaseResponseDto responseDto = new PurchaseResponseDto();

		responseDto.setId(updatedEvent.getEventId());
		responseDto.setEventName(updatedEvent.getEventName());

		BigDecimal totalPrice = event.getPrice().multiply(BigDecimal.valueOf(requestDto.getQuantity()));

		responseDto.setTotalPrice(totalPrice);

		return responseDto;
	}
}
