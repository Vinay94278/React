package com.challenge.entity;

import jakarta.persistence.*;

@Entity
public class Ticket {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long ticketId;
	private double ticketPrice;

	@ManyToOne
	private Event event;

	public Ticket() {
	}

	public Ticket(double price, Event e) {
		this.ticketPrice = price;
		this.event = e;
	}

	public Long getTicketId() {
		return ticketId;
	}

	public void setTicketId(Long id) {
		this.ticketId = id;
	}

	public double getTicketPrice() {
		return ticketPrice;
	}

	public void setTicketPrice(double p) {
		this.ticketPrice = p;
	}

	public Event getEvent() {
		return event;
	}

	public void setEvent(Event e) {
		this.event = e;
	}
}