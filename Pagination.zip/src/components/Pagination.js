import React from "react";
import Table from "./Table";

const Pagination = ({ data }) => {
  return (
    <>
      <div className="card flex flex-col items-center gap-8 p-8 mb-8">
        {/* Heading kept from Solution styling */}
        <h2 className="text-2xl font-semibold text-primary mb-2">Pagination Controls</h2>

        <div className="flex items-center gap-4">
          <label className="text-sm font-medium text-primary">Rows per page:</label>
          <select data-testid="selectInput" className="select w-20" onChange={(e) => e.preventDefault()}>
            <option value="5">5</option>
          </select>
        </div>

        <div className="button-div" data-testid="buttonDiv">
          <button className="btn btn-secondary">1</button>
          <button className="btn btn-secondary">2</button>
          <button className="btn btn-secondary">3</button>
          <button className="btn btn-secondary">4</button>
          <button className="btn btn-secondary">5</button>
        </div>
      </div>

      {/* Static table like in boilerplate */}
      <Table />
    </>
  );
};

export default Pagination;
