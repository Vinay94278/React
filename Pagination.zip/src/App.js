import React, { useState } from "react";
import "./App.css";
import info from "./info.json";
import { Pagination } from "./components";

const title = "React Pagination";

const App = () => {
  const [data] = useState([...info]);

  return (
    <div className="App">
      <nav className="navbar">
        <div className="navbar-brand">{title}</div>
      </nav>
      <div className="min-h-screen bg-background py-12">
        <div className="container mx-auto">
          <div className="max-w-4xl mx-auto">
            <Pagination data={data} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default App;
